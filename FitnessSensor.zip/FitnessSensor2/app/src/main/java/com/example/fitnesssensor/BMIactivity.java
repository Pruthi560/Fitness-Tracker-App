package com.example.fitnesssensor;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class BMIactivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmiactivity);

        EditText height = findViewById(R.id.eTHeight);
        EditText weight = findViewById(R.id.eTWeight);
        Button btnCalc = findViewById(R.id.btnBMI);
        TextView result = findViewById(R.id.tVResult);


        btnCalc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                float h = Float.parseFloat(height.getText().toString()) / 100;
                float w = Float.parseFloat(weight.getText().toString());

                float r = w / (h * h);


                result.setText(String.format("Your BMI is %.2f", r)); // Format to show two decimal places
            }
        });


    }
}