package com.example.fitnesssensor;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_card);



        ImageView Yoga = findViewById(R.id.Yoga);
        ImageView Tips = findViewById(R.id.Tips);
        ImageView bmi = findViewById(R.id.imgBMI);
        ImageView sensor = findViewById(R.id.imgPedoMeter);

        bmi.setOnClickListener(view -> {

            Intent intent = new Intent(CardActivity.this, BMIactivity.class);
            startActivity(intent);
        });

        sensor.setOnClickListener(view -> {
            Intent intent = new Intent(CardActivity.this, PedoSensor.class);
            startActivity(intent);
        });
        Yoga.setOnClickListener(view -> {

            Intent intent = new Intent(CardActivity.this, Yoga.class);
            startActivity(intent);
        });
        Tips.setOnClickListener(view -> {

            Intent intent = new Intent(CardActivity.this, Tips.class);
            startActivity(intent);
        });
    }
}