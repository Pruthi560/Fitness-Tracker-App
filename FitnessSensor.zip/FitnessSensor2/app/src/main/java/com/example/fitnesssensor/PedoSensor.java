package com.example.fitnesssensor;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PedoSensor extends AppCompatActivity implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor stepCounterSensor;
    private TextView stepCountTextView;

    private float initialStepCount = 0f; // To track steps from when the app starts
    private float currentStepCount = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedo_sensor);

        // Initialize sensorManager and find the step counter sensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

        // If the sensor is not available, show a message
        if (stepCounterSensor == null) {
            Toast.makeText(this, "Step counter sensor not available", Toast.LENGTH_SHORT).show();
        }

        // Set up the TextView where step count will be displayed
        stepCountTextView = findViewById(R.id.tv_stepsTaken);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register the sensor event listener when the activity is resumed
        if (stepCounterSensor != null) {
            sensorManager.registerListener(this, stepCounterSensor, SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister the sensor event listener to save battery and avoid memory leaks
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Check if the event is from the step counter sensor
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            float stepsTaken = event.values[0]; // Total steps since the device boot

            // Calculate the steps taken after the app was opened
            if (initialStepCount == 0f) {
                // Store the initial step count the first time this is called
                initialStepCount = stepsTaken;
            }

            // Calculate the steps taken since app opened
            currentStepCount = stepsTaken - initialStepCount;

            // Update the TextView with the current step count
            stepCountTextView.setText(String.valueOf((int) currentStepCount));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle sensor accuracy changes if needed (optional)
    }
}
